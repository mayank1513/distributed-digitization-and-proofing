let prevD = null;
var upTimer = null;

function simulateMouseEvents(element, eventName) {
    var mouseEvent = document.createEvent('MouseEvents');
    mouseEvent.initEvent(eventName, true, true);
    element.dispatchEvent(mouseEvent);
}

var update = function () {
    var btn = document.getElementsByClassName('seltab')[1];
    if (btn.classList[1] != 'active') {
        setTimeout(function () {
            btn.click();
            if (upTimer) clearTimeout(upTimer);
            upTimer = setTimeout(update, 400 + Math.random() * 400);
        }, 400 + Math.random() * 400)
        return;
    }

    browser.storage.local.get().then((storedSettings) => {
        var f = storedSettings.authCredentials.upFreq;
        var fu = storedSettings.authCredentials.upUnit;
        var m = fu == 'sec' ? 1000 : fu == 'min' ? 60000 : 3600000;
        // console.log(f + '; ' + m + '; m*f = ' + (m * f))
        // var elem = document.querySelector('#pagerFGI_center > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(8) > select:nth-child(1)');
        // simulateMouseEvents(elem, 'mousedown')
        if (upTimer) clearTimeout(upTimer);
        upTimer = setTimeout(update, f * m + Math.random() * 500);

        var refresh = function () {
            document.getElementById('btnRefreshStock').click();
            let f2 = function () {
                if (document.getElementById('load_tableFGI').style.display == 'block') {
                    setTimeout(f2, 400 + Math.random() * 500);
                    return;
                }
                if (storedSettings.authCredentials.downloadCsv)
                    document.getElementById('ExportGrid').click();

                let m = document.getElementById('tableFGI');
                let mp = document.getElementById('sp_1_pagerFGI');
                let np = document.getElementById('next_pagerFGI');
                let p = document.getElementsByClassName('ui-pg-input')[1];
                let d = [], c = [];

                let f1 = function () {
                    Array.prototype.push.apply(d, m.innerText.split('\n').slice(1));
                    if (p.value != mp.innerText) {
                        np.click();
                        setTimeout(f1, 100 + Math.random() * 100);
                    } else {
                        // browser.runtime.sendMessage({
                        //     type: "wa",
                        //     data: d.slice(0,storedSettings.authCredentials.upFreq)
                        // });

                        document.getElementById('first_pagerFGI').click();
                        if (prevD) {
                            // console.log("hari -- prev\n")
                            for (var i = 0; i < d.length; i++) {
                                if (!prevD.includes(d[i]))
                                    c.push(d[i]);
                            }
                            let name = storedSettings.authCredentials.waNmae;
                            let wa = storedSettings.authCredentials.wa;
                            if (name && wa) {
                                browser.runtime.sendMessage({
                                    type: "wa",
                                    data: c
                                });
                            }
                            if (storedSettings.authCredentials.downloadUpdateCsv) {
                                var headers = [' ', 'Case', 'Orig Ord', 'From', 'Quality', 'Finish', 'Ext Type', 'Carbon', 'Coating', 'Nom Gauge', 'Actual Gauge',
                                    'Width', 'Good Width', 'Edge', 'Length', 'Pieces', 'Mass', 'Centre', 'Pack Together'];
                                let blob = new Blob([(new Date()).toString() + ',,,,,,,,,,,,,,,,,,,,\n\n'
                                    + headers.join(',') + '\n' + c.join('\n').replace(/\t/g, ',')], { type: 'text/plain' });
                                var a = document.createElement("a");
                                a.href = window.URL.createObjectURL(blob);
                                a.download = "update.csv";
                                document.body.appendChild(a);
                                a.click();
                                document.removeChild(a);
                            }
                        }
                        prevD = d;
                        // console.log('hari--');
                    }
                }
                f1();
            }
            f2();
        }
        setTimeout(function () {
            refresh();
        }, 600 + Math.random() * 500)
    })
}

window.addEventListener('load', function () {
    upTimer = setTimeout(update, 400 + Math.random() * 400);
}, false);

browser.runtime.onMessage.addListener(request => {
    if (request.msg == 'reset') {
        if(upTimer) clearTimeout(upTimer);
        upTimer = setTimeout(update, 600 + Math.random() * 400);
    }
});