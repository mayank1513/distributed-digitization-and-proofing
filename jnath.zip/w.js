function simulateMouseEvents(element, eventName) {
    var mouseEvent = document.createEvent('MouseEvents');
    mouseEvent.initEvent(eventName, true, true);
    element.dispatchEvent(mouseEvent);
}

browser.runtime.sendMessage({
    type: "login_wa"
});

var eventFire = (MyElement, ElementType) => {
    var MyEvent = document.createEvent("MouseEvents");
    MyEvent.initMouseEvent
        (ElementType, true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
    MyElement.dispatchEvent(MyEvent);
};

browser.runtime.onMessage.addListener(request => {
    browser.storage.local.get().then((storedSettings) => {
        let name = storedSettings.authCredentials.waNmae;
        let wa = storedSettings.authCredentials.wa;
        var target = null;
        if (wa && name) target = document.querySelector('[title="' + name + '"]');
        if (target) {
            simulateMouseEvents(target, 'mousedown');
            setTimeout(function () {
                messageBox = document.querySelectorAll("[contenteditable='true']")[0];
                message = request.msg; 
                if (message == 'paste') {
                    messageBox.focus();
                    document.execCommand("paste");
                    setTimeout(function () {
                        eventFire(document.querySelector('span[data-icon="send-light"]'), 'click'); 
                    }, 400 + Math.random() * 500)
                } else {
                    // var downloadUrl = URL.createObjectURL(blob);
                    // var a = document.createElement("a");
                    // a.href = downloadUrl;
                    // a.download = "data.csv";
                    event = document.createEvent("UIEvents");
                    messageBox.innerHTML = message;//.replace(/  /gm, ' '); // test it 
                    event.initUIEvent("input", true, true, window, 1);
                    messageBox.dispatchEvent(event);
                    eventFire(document.querySelector('span[data-icon="send"]'), 'click');
                }
            }, 500 + Math.random() * 400);
        }
    })
});