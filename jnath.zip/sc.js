browser.runtime.sendMessage({
    type: "ext-page"
});

var headers = ['Case', 'From', 'Quality', 'Finish', 'Ext Type', 'Carbon', 'Coating', 'Nom Gauge', 'Actual Gauge',
    'Width', 'Good Width', 'Edge', 'Length', 'Pieces', 'Mass', 'Centre', 'Pack Together'];

function sendUpdate(tab, c) {
    let t = document.getElementById('t');
    t.innerHTML = '';
    var row = document.createElement('tr');
    row.innerHTML = '<td colspan = 17>' + new Date() + '</td>';
    t.appendChild(row);
    row = document.createElement('tr');
    for (var i = 0; i < headers.length; i++) {
        var col = document.createElement('td');
        col.innerText = headers[i];
        row.appendChild(col);
    }
    t.appendChild(row);

    for (var i = 0; i < c.length; i++) {
        var ci = c[i].split('\t');
        row = document.createElement('tr');
        for (var j = 1; j < ci.length; j++) {
            if (j == 2) continue;
            var col = document.createElement('td');
            col.innerText = ci[j];
            row.appendChild(col);
        }
        t.appendChild(row);
    }

    var canvas = document.getElementById("canvas");
    canvas.height = t.offsetHeight;
    canvas.width = t.offsetWidth;
    var ctx = canvas.getContext("2d");

    var data = "<svg xmlns='http://www.w3.org/2000/svg' width='" + t.offsetWidth + "' height='" + t.offsetHeight + "'>" +
        "<foreignObject width='100%' height='100%'>" +
        "<div xmlns='http://www.w3.org/1999/xhtml' style='font-size:16px'>" +
        "<table>" + t.innerHTML + "</table>" +
        "<style>td{padding: 2px;border: 1px solid black;text-align: center;white-space: nowrap;}" +
        " table{text-align: center;background: white}</style>" +
        "</div>" +
        "</foreignObject>" +
        "</svg>";
    var DOMURL = self.URL || self.webkitURL || self;
    var img = new Image();
    var svg = new Blob([data], { type: "image/svg+xml;charset=utf-8" });
    var url = DOMURL.createObjectURL(svg);
    img.onload = function () {
        ctx.drawImage(img, 0, 0);
        DOMURL.revokeObjectURL(url);
        console.log('image loaded')
        url = canvas.toDataURL("image/jpg");
        fetch(url)
            .then(response => response.arrayBuffer())
            .then(buffer => {
                browser.tabs.query({active: true}).then((tabs) => {
                    browser.clipboard.setImageData(buffer, 'png')
                    browser.tabs.sendMessage(tab.id, { msg: 'paste' })
                    browser.tabs.update(tab.id, {
                        active: true
                    });
                    setTimeout(function(){
                        browser.tabs.update(tabs[0].id, {
                            active: true
                        });
                    }, 50);
                });
            });
    };
    img.src = url;
    // t.innerHTML = '';
    // setTimeout(function () {
    //     // img = document.getElementById('img');
    //     // img.src = url;
    //     // -------working solution but can't paste to whatsapp
    //     // var r = document.createRange();
    //     // r.setStartBefore(img);
    //     // r.setEndAfter(img);
    //     // r.selectNode(img);
    //     // var sel = window.getSelection();
    //     // sel.addRange(r);
    //     // document.execCommand('Copy');
    //     // ------------------------------------------
}

var c;
function f() {
    browser.tabs.query({}).then((tabs) => {
        var i = 0;
        for (; i < tabs.length; i++) {
            let tab = tabs[i];
            if (tab.url.endsWith('whatsapp.com/')) {
                if (c.length) {
                    var j = 0;
                    var fu = function () {
                        if (j < c.length) {
                            sendUpdate(tab, c.slice(j, j + 5));
                            j = j + 5;
                            setTimeout(fu, 1000)
                        }
                    }
                    fu();
                } else
                    browser.tabs.sendMessage(tab.id, { msg: 'no update' });
                break;
            }
        }
        if (i == tabs.length) {
            browser.tabs.create({ url: "https://web.whatsapp.com/viewer.html" })
                .then(function () {
                    setTimeout(f, 5500 + Math.random() * 500);
                });
        }
    });
}

browser.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.type == 'wa1') {
        c = request.data;
        f();
    }
});