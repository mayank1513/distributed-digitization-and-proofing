var target = "*://*.commercial.bahrustainless.com/*";

let u = document.getElementById('uname');
let p = document.getElementById('password');
let f = document.getElementById('upFreq');
let fu = document.getElementById('t');
let wa = document.getElementById('wa');
let waInfo = document.getElementById('info');
let dCSVInfo = document.getElementById('d_info');
let waName = document.getElementById('waName');
let dCSV = document.getElementById('csv');
let dUpdateCSV = document.getElementById('u_csv');
let authCredentials = null;

if (wa.checked && !waName.value) {
  waInfo.style.display = 'inline';
} else waInfo.style.display = 'none';

wa.onclick = function () {
  if (wa.checked && !waName.value) {
    waInfo.style.display = 'inline';
  } else waInfo.style.display = 'none';
}

waName.onchange = function () {
  if (wa.checked && !waName.value) {
    waInfo.style.display = 'inline';
  } else waInfo.style.display = 'none';
}

document.getElementById('save').onclick = function () {
  authCredentials.username = u.value;
  authCredentials.password = p.value;
  authCredentials.upFreq = f.value;
  authCredentials.upUnit = fu.value;
  authCredentials.wa = wa.checked;
  authCredentials.downloadCsv = dCSV.checked;
  authCredentials.downloadUpdateCsv = dUpdateCSV.checked;
  authCredentials.waNmae = waName.value;
  browser.storage.local.set({ authCredentials });
  browser.tabs.query({})
    .then((tabs) => {
      var i = 0;
      for (; i < tabs.length; i++) {
        let tab = tabs[i];
        if (tab.url.match('bahrustainless')) {
          browser.tabs.update(tab.id, {
            active: true
          });
          if (tab.url.match('stocklist.bahrustainless.com/Stocklist/StocklistMain.php'))
            browser.tabs.sendMessage(tab.id, { msg: "reset" });
          break;
        }
      }
    });
  console.log(authCredentials)
}

browser.storage.local.get().then((storedSettings) => {
  authCredentials = storedSettings.authCredentials;
  u.value = authCredentials.username;
  p.value = authCredentials.password;
  f.value = authCredentials.upFreq;
  fu.value = authCredentials.upUnit;
  wa.checked = authCredentials.wa;
  dCSV.checked = authCredentials.downloadCsv;
  dUpdateCSV.checked = authCredentials.downloadUpdateCsv;
  waName.value = authCredentials.waNmae;
})

browser.tabs.query({})
  .then((tabs) => {
    var i = 0;
    for (; i < tabs.length; i++) {
      let tab = tabs[i];
      if (tab.url.match('bahrustainless')) {
        document.getElementById('go').onclick = function (e) {
          e.preventDefault();
          browser.tabs.update(tab.id, {
            active: true
          });
        }
        break;
      }
    }
  });