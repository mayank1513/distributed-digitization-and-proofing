window.addEventListener('load', function () {
    setTimeout(function () {
        document.getElementsByTagName('a')[2].click();
    }, 300 + Math.random() * 500);
}, false)