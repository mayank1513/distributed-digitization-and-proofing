var authCredentials = {
  username: "STK00267",
  password: "rakesh21",
  showUsr: true,
  showPs: false,
  upFreq: 5,
  upUnit: "min",
  wa: false,
  downloadCsv: false,
  downloadUpdateCsv: true,
  waNmae: "",
  showNot: true
}

browser.runtime.sendMessage({
  type: "login"
});

browser.storage.local.get().then((storedSettings) => {
  if (!storedSettings.authCredentials) {
    browser.storage.local.set({ authCredentials });
  } else {
    authCredentials = storedSettings.authCredentials;
  }
  document.getElementById('username').value = authCredentials.username;
  document.getElementById('password').value = authCredentials.password;
});