var authCredentials = {
  username: "STK00267",
  password: "rakesh21",
  upFreq: 5,
  upUnit: "min",
  downloadCsv: false,
  downloadUpdateCsv: true,
  wa: false,
  waNmae: "",
  showNot: true
}
//   "vishal@justanalytics.com"

browser.storage.local.get().then(function (storedSettings) {
  if (!storedSettings.authCredentials) {
    browser.storage.local.set({ authCredentials });
  }
});

var switchIfExists = function (u, sender) {
  browser.tabs.query({})
    .then((tabs) => {
      for (var i = 0; i < tabs.length; i++) {
        let tab = tabs[i];
        if (tab.url.match(u) && tab.id != sender.tab.id) {
          browser.tabs.update(tab.id, {
            active: true
          });
          browser.tabs.remove(sender.tab.id);
          break;
        }
      }
    });
}

browser.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.type == 'login') {
    switchIfExists('bahrustainless', sender);
  } else if (request.type == 'login_wa') {
    switchIfExists('whatsapp.com', sender);
  } else if (request.type == 'ext-page') {
    switchIfExists(/moz-extension.*viewer/, sender);
  } else if (request.type == 'wa') {
    var f = function () {
      browser.runtime.sendMessage({
        type: "wa1",
        data: request.data
      });
    };
    browser.tabs.query({})
      .then((tabs) => {
        var i = 0
        for (; i < tabs.length; i++)
          if (tabs[i].url.match(/moz-extension.*viewer/)) break;
        if (i >= tabs.length) {
          browser.tabs.create({ active: false, url: "viewer.html" })
            .then(function () {
              setTimeout(f, 500)
            })
        } else {
          f();
        }
      });
  }
});