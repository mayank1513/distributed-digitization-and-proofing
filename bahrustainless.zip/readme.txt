Follow these steps to get up and running

Method 1:
1. Close FireFox browser and extract the content of zip file to any folder
2. run install_bahrustainless.bat
3. wait untill firefox opens
4. Go to settings and enable extension
5. Click on extension button to manage settings
6. launch website -> enter captcha -> Login
7. Login to Whatsapp web if not already logged in (if you are sending data to whatsapp)
-- the files are saved to default download folder - you can manage it in firefox settings.

Happy to help